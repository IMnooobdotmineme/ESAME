import { create } from "zustand";

export interface StudentRequest {
  id: string;
  name: string;
  status: "pending" | "approved" | "rejected";
  timestamp: string;
  currentQuestion?: number;
  tabSwitches?: number;
  isSubmitted?: boolean;
  isLocked?: boolean;
  lastLockedAt?: string;
}

export interface Exam {
  id: string;
  courseCode: string;
  title: string;
  durationMinutes: number;
  questionCount: number;
  roomCode: string;
  isStarted?: boolean;
  isEnded?: boolean;
  requests: StudentRequest[];
  parts?: unknown[];
  scheduledStartAt?: string; // ISO timestamp — when the exam should auto-start
}

export interface CreateExamInput {
  title: string;
  courseCode: string;
  durationMinutes: number;
  parts: unknown[];
  questionCount: number;
  scheduledStartAt?: string;
}

interface ExamStore {
  exams: Exam[];
  requestToJoin: (
    roomCode: string,
    studentName: string
  ) => { success: boolean; message?: string; requestId?: string };
  getStudentStatus: (
    roomCode: string,
    requestId: string
  ) => "pending" | "approved" | "rejected" | null;
  approveStudent: (roomCode: string, requestId: string) => void;
  rejectStudent: (roomCode: string, requestId: string) => void;
  deleteExam: (id: string) => void;
  startExam: (roomCode: string) => void;
  endExam: (roomCode: string) => void;
  flagTabSwitch: (roomCode: string, requestId: string) => void;
  grantContinue: (roomCode: string, requestId: string) => void;
  createExam: (input: CreateExamInput) => { id: string; roomCode: string };
  updateExam: (id: string, input: Partial<CreateExamInput>) => void;
}

function generateRoomCode(existingCodes: string[]): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  do {
    code = "";
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
  } while (existingCodes.includes(code));
  return code;
}

export const useExamStore = create<ExamStore>((set, get) => ({
  exams: [
    {
      id: "1",
      courseCode: "DEMO",
      title: "Demo Exam Session",
      durationMinutes: 60,
      questionCount: 5,
      roomCode: "DEMO123",
      isStarted: false,
      isEnded: false,
      requests: [
        {
          id: "req-1",
          name: "Alex Johnson",
          status: "approved",
          timestamp: "10:00 AM",
          currentQuestion: 1,
          tabSwitches: 0,
          isSubmitted: false,
          isLocked: false,
        },
      ],
    },
    {
      id: "2",
      courseCode: "CS101",
      title: "Introduction to Computer Science (Midterm)",
      durationMinutes: 60,
      questionCount: 10,
      roomCode: "X8K29P",
      isStarted: false,
      isEnded: false,
      requests: [],
    },
  ],

  requestToJoin: (roomCode, studentName) => {
    const state = get();
    const examIndex = state.exams.findIndex(
      (e) => e.roomCode.toUpperCase() === roomCode.toUpperCase()
    );

    if (examIndex === -1) {
      return { success: false, message: "Invalid Room Code. Please check and try again." };
    }

    const newRequestId = `req-${Date.now()}`;
    const newRequest: StudentRequest = {
      id: newRequestId,
      name: studentName,
      status: "pending",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      currentQuestion: 1,
      tabSwitches: 0,
      isSubmitted: false,
      isLocked: false,
    };

    const updatedExams = [...state.exams];
    updatedExams[examIndex].requests.push(newRequest);

    set({ exams: updatedExams });
    return { success: true, requestId: newRequestId };
  },

  getStudentStatus: (roomCode, requestId) => {
    const exam = get().exams.find((e) => e.roomCode.toUpperCase() === roomCode.toUpperCase());
    if (!exam) return null;
    const req = exam.requests.find((r) => r.id === requestId);
    return req ? req.status : null;
  },

  approveStudent: (roomCode, requestId) => {
    set((state) => ({
      exams: state.exams.map((exam) => {
        if (exam.roomCode.toUpperCase() !== roomCode.toUpperCase()) return exam;
        return {
          ...exam,
          requests: exam.requests.map((req) =>
            req.id === requestId ? { ...req, status: "approved" as const } : req
          ),
        };
      }),
    }));
  },

  rejectStudent: (roomCode, requestId) => {
    set((state) => ({
      exams: state.exams.map((exam) => {
        if (exam.roomCode.toUpperCase() !== roomCode.toUpperCase()) return exam;
        return {
          ...exam,
          requests: exam.requests.map((req) =>
            req.id === requestId ? { ...req, status: "rejected" as const } : req
          ),
        };
      }),
    }));
  },

  deleteExam: (id) => {
    set((state) => ({
      exams: state.exams.filter((exam) => exam.id !== id),
    }));
  },

  startExam: (roomCode) => {
    set((state) => ({
      exams: state.exams.map((exam) =>
        exam.roomCode.toUpperCase() === roomCode.toUpperCase()
          ? { ...exam, isStarted: true, isEnded: false }
          : exam
      ),
    }));
  },

  endExam: (roomCode) => {
    set((state) => ({
      exams: state.exams.map((exam) =>
        exam.roomCode.toUpperCase() === roomCode.toUpperCase()
          ? { ...exam, isEnded: true }
          : exam
      ),
    }));
  },

  flagTabSwitch: (roomCode, requestId) => {
    set((state) => ({
      exams: state.exams.map((exam) => {
        if (exam.roomCode.toUpperCase() !== roomCode.toUpperCase()) return exam;
        return {
          ...exam,
          requests: exam.requests.map((req) =>
            req.id === requestId
              ? {
                  ...req,
                  tabSwitches: (req.tabSwitches ?? 0) + 1,
                  isLocked: true,
                  lastLockedAt: new Date().toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  }),
                }
              : req
          ),
        };
      }),
    }));
  },

  grantContinue: (roomCode, requestId) => {
    set((state) => ({
      exams: state.exams.map((exam) => {
        if (exam.roomCode.toUpperCase() !== roomCode.toUpperCase()) return exam;
        return {
          ...exam,
          requests: exam.requests.map((req) =>
            req.id === requestId ? { ...req, isLocked: false } : req
          ),
        };
      }),
    }));
  },

  createExam: (input) => {
    const state = get();
    const existingCodes = state.exams.map((e) => e.roomCode);
    const roomCode = generateRoomCode(existingCodes);
    const id = `exam-${Date.now()}`;

    const newExam: Exam = {
  id,
  courseCode: input.courseCode,
  title: input.title,
  durationMinutes: input.durationMinutes,
  questionCount: input.questionCount,
  roomCode,
  isStarted: false,
  isEnded: false,
  requests: [],
  parts: input.parts,
  scheduledStartAt: input.scheduledStartAt,
};

    set({ exams: [newExam, ...state.exams] });
    return { id, roomCode };
  },

  updateExam: (id, input) => {
    set((state) => ({
      exams: state.exams.map((exam) =>
        exam.id === id
          ? {
              ...exam,
              ...(input.title !== undefined && { title: input.title }),
              ...(input.courseCode !== undefined && { courseCode: input.courseCode }),
              ...(input.durationMinutes !== undefined && { durationMinutes: input.durationMinutes }),
              ...(input.questionCount !== undefined && { questionCount: input.questionCount }),
              ...(input.parts !== undefined && { parts: input.parts }),
            }
          : exam
      ),
    }));
  },
}));